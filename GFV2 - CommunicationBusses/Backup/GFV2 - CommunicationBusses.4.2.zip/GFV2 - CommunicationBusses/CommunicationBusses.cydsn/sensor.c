/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "project.h"
#include "stdio.h"

uint8_t responseData[0] ;

void Read2Bytes(uint8_t data[], uint8_t address)
{
    //I2C Communication
    uint8_t response;
    I2C_MasterClearStatus();
    //I2C Start
    response = I2C_MasterSendStart(address, 1) ;
    if (I2C_MSTR_NO_ERROR == response) {   
        data[0] = I2C_MasterReadByte(I2C_ACK_DATA); // Integer
        data[1] = I2C_MasterReadByte(I2C_NAK_DATA); // Fraction
        I2C_MasterSendStop();
    }
        else
    {
        // error
        UART_1_PutString("Error in fetching temp from LM75");
        UART_1_PutString("\r\n");        
    }    
    //I2C Stop 
}
float getTemp(uint8_t address){
    Read2Bytes(responseData, address); // reads from I2C
    float combinedValues  = (float)(((responseData[0] << 8) | responseData[1]) >> 5) * 0.125;
    return combinedValues;
}
/* [] END OF FILE */
